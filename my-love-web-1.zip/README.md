# My Love — browser version

Open `index.html` in a browser to preview it.

## Put it online for a shareable link

1. Create a GitHub account if you don't already have one.
2. Create a new repository, for example `my-love`.
3. Upload `index.html`.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. GitHub will give you a public `github.io` link you can send.

No Python or VS Code is needed for the person opening the link.
